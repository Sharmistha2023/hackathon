import click
import requests
import os
import re
from pathlib import Path
import yaml
import time
from d3x_cli.utils import output_convertion, get_dkubex_apikey
userdata_dir = (
    "/userdata" if "D3X_NAMESPACE" in os.environ else str(Path.home())
)
ini_file = f"{userdata_dir}/.d3x.ini"

from websockets.sync.client import connect
from websockets.exceptions import ConnectionClosedError

class Struct:
    def __init__(self, **entries):
        self.__dict__.update(entries)


def url_prefix(context):
    if context.auth_type == "cookie":
        prefix = "llms"
    else:
        # TODO: can we change the name to 'serve' instead of 'llm'
        prefix = "llm"
    return prefix


CLI_CTX_OBJ = None


@click.group()
@click.pass_obj
def llms(obj):
    """Group for llms commands."""
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj


@llms.command()
@click.pass_obj
@click.option("-n", "--name", required=True, help="name of the deployment")
@click.option(
    "-m",
    "--model",
    required=False,
    help="name or path of the model to deploy for serving",
)
@click.option("--base_model", required=False, help="base model name")
@click.option("--token", help="hugging face token")
@click.option("--config", help="github raw content url or local config path")
@click.option(
    "--mlflow",
    help="name of the mlflow registered model along with version (example: diffusion:1)",
)
@click.option(
    "--image", required=False, help="customized docker image for llm deployment"
)
@click.option("--type", "instance_type", help="instance type")
@click.option("--min_replicas", help="minimum replicas")
@click.option("--max_replicas", help="maximum replicas")
@click.option("--publish", is_flag=True, help="publish the deployment")
@click.option(
    "-o",
    "--output",
    required=False,
    type=click.Choice(
        [
            "yaml",
            "json",
        ]
    ),
    help="supported only json,yaml",
)
@click.option(
    "-p",
    "--provider",
    required=False,
    default="dkubex",
    help="provider of llm [default is dkubex]",
)
@click.option(
    "--ngc-api-key", "ngcapikey", required=False, help="NGC API key for nim provider"
)
@click.option(
    "--qps", "qps", required=False, help="questions per second for autoscaling"
)
@click.option(
    "-sky",
    "--sky",
    "skyjob",
    required=False,
    default=False,
    is_flag=True,
    help="If the model should be deployed on remote sky cluster.",
)
@click.option(
    "-sc",
    "--sky-cloud",
    "sky_cloud",
    required=False,
    help="Name of the sky cloud, if not provided cloud will be selected based on cost.",
)
@click.option(
    "--sky-accelerator",
    "accelerator",
    default=None,
    help="accelerator for remote sky cluster",
)
@click.option(
    "--sky-yaml",
    "sky_yaml",
    required=False,
    default=None,
    help="Path to custom yaml file for sky serve.",
)
@click.option(
    "--use-spot",
    "use_spot",
    required=False,
    default=False,
    is_flag=True,
    help="Whether to request spot instances for sky deployments.",
)

@click.option(
    "--ngpus",
    "ngpus",
    default=0,
    help="no.of gpus",
)

@click.option(
    "--ncpus",
    "ncpus",
    required=False,
    help="no.of cpus",
)

@click.option(
    "--memory",
    "memory",
    required=False,
    help="memory in GB",
)

def deploy(
    obj,
    name,
    model,
    base_model,
    token,
    config,
    mlflow,
    image,
    instance_type,
    min_replicas,
    max_replicas,
    publish,
    output,
    provider,
    ngcapikey,
    skyjob,
    sky_cloud,
    qps,
    accelerator,
    sky_yaml,
    use_spot,
    ngpus,
    ncpus=None,
    memory=None,
):
    """Deploy a llm on dkubex."""
    kserve = True
    if use_spot and (not skyjob):
        print("--use-spot option is only supported for sky deployments.")
        return

    if skyjob and (not model) and (not config) and not mlflow:
        print("Please provide a model (--model) or config file (--config) for deploying on remote sky cluster")
        return
    if provider == "nim":
        if  ngcapikey==None:
            print("Please provide --ngc-api-key")
            click.Abort()
            return
        else:
            token = ngcapikey
    dkubex_apikey = None
    if (skyjob): #assert dkubex_apikey, "For sky jobs, -k/--dkubex-apikey must be passed."
        dkubex_apikey = get_dkubex_apikey(obj)
        kserve = False

    if not model and not config and not mlflow:
        print("please provide either model, config ")
        return
    # if mlflow:
    #    token = ""
    # TODO: mlflow only if model provided is path ...?

    prefix = url_prefix(obj)
    resp = requests.get(
        f"{obj.url}/{prefix}/api/llms/", headers=obj.headers, verify=False
    )

    llmsdb = resp.json()["llms"]
    if config:
        with open(config, "r") as file:
            yamlstr = file.read()
            config = yaml.safe_load(yamlstr)

    # if Path(model).exists():

    if model and not Path(model).exists():
        for entry in llmsdb:
            if entry["model_id"] == model and entry["provider"] == provider:
                model = entry["name"]
                if not mlflow and entry.get("needs_token", False) == True and (not token):
                    token = input(
                        "This model requires huggingface token, please input : "
                    )
                break
    data = {
        "depname": name,
        "llm": {
            "name": model,
            "token": token,
            "config": config,
            "image": image,
            "base_model": base_model,
            "instance_type": instance_type,
            "publish": publish,
            "mlflow": mlflow,
            "provider":provider,
            "kserve": kserve,
            "ngpus": ngpus,

        },
        "sky": {
            "skyjob": skyjob,
            "accelerator": accelerator,
            "sky_yaml": sky_yaml,
            "use_spot": use_spot,
            "no_stream": True,
        },
        "dkubex_apikey": dkubex_apikey,
    }
    if sky_cloud:
        data["sky"]["sky_cloud"] = sky_cloud

    if ncpus:
        data["llm"]["ncpus"] = ncpus
    if memory:
        data["llm"]["memory"] = str(memory)
    if qps:
        data["llm"]["qps"] = qps
    prefix = url_prefix(obj)
    if min_replicas:
        data["llm"]["min_replicas"] = min_replicas
    if max_replicas:
        data["llm"]["max_replicas"] = max_replicas

    post_url = f"{obj.url}/{prefix}/api/llms/deploy"
    if (skyjob) :
        post_url =  f"{obj.url}/{prefix}/api/llms/deploy/sky"

    r = requests.post(
        post_url,
        json=data,
        headers=obj.headers,
        verify=False,
        timeout=360,
    )

    if r.status_code != 200:
        print(f"Failed to deploy model. Status code: {r.status_code} , {r.text}")
        return

    if skyjob:
        data =""
        while True:
            r = requests.get (
                f"{obj.url}/{prefix}/api/skydeploymentstatus/{name}",
                headers=obj.headers,
                verify=False,
                timeout=360,
                )
            
            if r.status_code != 200:
                print(f"Failed to deploy model. Status code: {r.status_code} , {r.text}")
                return
            
            resp = r.json()
            if resp["status"] in ["init", "deploying"]:
                msg = resp["logs"]
                msg = msg.replace(data, "")
                print(msg, end="", flush=True)
                data =  resp["logs"]
            else:
                status = resp["status"]
                print(f"deployment {name} is in {status} state")
                break
            time.sleep(10)

        return
    if output is None:
        print(r.json())
    else:
        output_convertion(r.json(), output)

    return


# @llms.command()
# @click.pass_obj
# @click.option("-n", "--name", required=True, help="name of the model for registration")
# @click.option(
#    "-f", "--file", required=True, help="raw github url of model definition in yaml"
# )
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)

def register(obj, name, file,output):
    """Register a model with dkubex"""
    # MAK - TODO
    pattern = r"https://raw\.githubusercontent\.com/[^/]+/[^/]+/[^/]+/[^/]+/.+"
    if not re.match(pattern, file):
        print("please provide valid raw github url")
        return
    prefix = url_prefix(obj)
    data = {"name": name, "file": file}
    resp = requests.post(
        f"{obj.url}/{prefix}/api/llms/register",
        json=data,
        headers=obj.headers,
        verify=False,
    )
    if output is None:
        print(resp.json())
    else:
        output_convertion(resp.json(), output)
        
    return


@llms.command()
@click.pass_obj
@click.option("-o","--output", required=False,
    type=click.Choice(["yaml", "json"]),
    help="supported only json,yaml",
)
def list(obj, output):
    """List the supported llms"""
    
    prefix = url_prefix(obj)
    
    resp = requests.get(
        f"{obj.url}/{prefix}/api/llms/", headers=obj.headers, verify=False
    )
    llmsdb = sorted(resp.json()["llms"], key=lambda x: x["name"])

    if output is not None:
        # Prepare data for output conversion
        table_output = [["Name", "ID", "Accelerator", "Provider", "DeploymentConfig"]]
        for entry in llmsdb:
            table_output.append([
                entry["name"],
                entry["model_id"], 
                entry["accelerator"], 
                entry["provider"], 
                entry.get("config", "")
            ])
        output_convertion(table_output, output)
    else:
        # Display rich table output
        from rich.console import Console
        from rich.table import Table

        console = Console()
        table = Table(
            show_header=True,
            header_style="bold magenta",
            title="LLM models supported on DKubeX.",
            show_lines=True,
        )
        
        table.add_column("NAME")
        table.add_column("LLM ID")
        table.add_column("Accelerator")
        table.add_column("Provider")
        table.add_column("DeploymentConfig", justify="left")
        
        for entry in llmsdb:
            table.add_row(
                entry["name"],
                entry["model_id"],
                entry["accelerator"],
                entry["provider"],
                entry.get("config", "")
            )
        
        console.print(table)
