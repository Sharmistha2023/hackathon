import click
import requests
from d3x_cli.workspace_helper import *
from websockets.sync.client import connect
from websockets.exceptions import ConnectionClosedError
import ssl
import os
import mlflow

def check_mlflow_run_exists(user, name):
    filter_string = f"tags.user='{user}' and tags.finetuning_name='{name}'"
    runs = mlflow.search_runs(filter_string=filter_string, search_all_experiments=True)
    if len(runs) > 0 :
        return True
    return False

@click.group()
@click.pass_obj
def qagen(obj):
    """Group for question and answer generation  commands."""
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj

def _logs(obj, job_name):
    url = obj.url.replace("http","ws")
    with connect(f"{url}/logs/{job_name}", additional_headers=obj.headers, open_timeout=420, ssl_context=ssl._create_unverified_context()if "wss" in url else None) as websocket:
        try:
            for msg in websocket:
                msg = msg.replace("\\n", "\n").replace("\"","")
                print(msg, end="", flush=True)
        except ConnectionClosedError:
            print("Timed out waiting. "
              "Please tail the logs using the following command: \n"
              f"kubectl logs -l job-name={job_name} --follow")
        except:
            websocket.close()
            raise


def _genqahandler(obj, inpath, promptfile,  outpath, openai_api_key, openai_base_url=""):
    cpwd = os.getcwd()
    if not inpath.startswith("/"):
        inpath = f"{cpwd}/{inpath}"
    if not promptfile.startswith("/"):
        promptfile = f"{cpwd}/{promptfile}"
    if not outpath.startswith("/"):
        outpath = f"{cpwd}/{outpath}"

    data = {"inpath": inpath, "promptfile": promptfile, "outpath": outpath, "openai_api_key" :openai_api_key, "openai_base_url": openai_base_url}
    print(obj.url)
    r = requests.post(obj.url + "/qagen", json=data, headers=obj.headers, verify=False, allow_redirects=False)
    print(r)
    if r.status_code == 200:
        return r.json()
    else:
        rsp = r.json()
        if 'detail' in rsp:
            print(rsp['detail'])
        else:
            print(rsp)
        raise click.Abort()


@qagen.command()
@click.pass_obj
@click.option("-i","--inpath", "inpath", required= True, help="Input file or directory path")
@click.option("-p","--promptfile", "promptfile", required= True, help="promptfile file path")
@click.option("-o","--outpath", "outpath", required=True, help="Output directory path")
@click.option("-k","--api_key", "openai_api_key", required=True, help="API key for the model or OPENAI API KEY")
@click.option("-b","--model_base_url", "openai_base_url", required=False, default="", help="Model base URL for the model, dont pass it incase of OPENAI")
def generate(obj, inpath, promptfile, outpath, openai_api_key, openai_base_url):
    """generate questions and answers"""
    if obj.auth_type == "cookie":
        obj.url += "/api/ft"
    else:
        obj.url += "/api/ft-api"
    resp = _genqahandler(obj, inpath=inpath, promptfile=promptfile, outpath=outpath, openai_api_key=openai_api_key, openai_base_url=openai_base_url)
    if resp and type(resp) == dict and resp["status"] == "OK":
        print("jobname :",  resp["job"] )
        _logs(obj, resp["job"])

@qagen.command()
@click.pass_obj
def jobs(obj):
    """list qagen jobs currently active"""
    prefix = "api/ft" if obj.auth_type == "cookie" else "api/ft-api"  
    r = requests.get(f"{obj.url}/{prefix}/qagenjobs",  headers=obj.headers, verify=False)
    print(r.text.replace("\\n", "\n").replace("\"",""))

@qagen.command()
@click.pass_obj
@click.argument( "name", required=True)
def logs(obj,name):
    """qagen job logs"""
    obj.url +="/api/ft" if obj.auth_type == "cookie" else "/api/ft-api" 
    _logs(obj, name)

@qagen.command()
@click.pass_obj
@click.argument( "name", required=True)
def delete(obj,name):
    """delete qagen job"""
    prefix = "api/ft" if obj.auth_type == "cookie" else "api/ft-api"  
    r = requests.delete(f"{obj.url}/{prefix}/jobs/{name}",  headers=obj.headers, verify=False)
    if r.status_code == 200:
        print(r.text.replace("\\n", "\n").replace("\\\"",""))
    else :
        print(r.text())

