import click
import requests
import json
from d3x_cli.utils import  get_formatted_name,output_convertion
from d3x_cli.workspace_helper import *

@click.group()
@click.pass_obj
def tensorboard(obj):
    """Group for tensorboard commands."""
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj

@tensorboard.command()
@click.pass_obj
@click.argument("logdir")
@click.option("-w","--workspace", required=False, default="default workspace", help="workspace name if it is not default workspace",)
@click.option("-o","--output", required=False, default="json",
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def set_logdir(obj, logdir, workspace, output):
    """setting log directory for tensorboard app inside workspace"""
    w = get_user_workspace(obj, exit=False)
    wid = w.id if w != None and w.name == workspace  else -1
    params={"workspace_name": get_formatted_name(workspace)}
    if not logdir.startswith("s3://") and not logdir.startswith("mlflow-artifacts:/") and not logdir.startswith(f"/home/{obj.username}/"):
        click.echo("only absolute path inside user's home directory in workspace is supported")
        raise click.Abort()
    resp = requests.post(
        f"{obj.url}/api/{obj.api_prefix}/workspaces/{wid}/tensorboard/logdir",
        data= json.dumps({"logdir" : logdir}),
        headers=obj.headers,
        params=params,
        verify=False,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    if output is None:
        click.echo(resp.json()["status"])
    else:
        click.echo(output_convertion(resp.json()["status"], output))

    click.echo(f"updated tensorboard log directory to {logdir}, please restart the tensorboard app from ui")

@tensorboard.command()
@click.pass_obj
@click.option("-w","--workspace", required=False, default="default workspace", help="workspace name if it is not default workspace",)
@click.option("-o","--output", required=False, default="json",
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def get_logdir(obj, workspace, output):
    """getting log directory for tensorboard"""
    w = get_user_workspace(obj, exit=False)
    wid = w.id if w != None and w.name == workspace else -1
    params={"workspace_name": get_formatted_name(workspace)}
    resp = requests.get(
        f"{obj.url}/api/{obj.api_prefix}/workspaces/{wid}/tensorboard/logdir",
        verify=False,
        params=params,
        headers=obj.headers,
    )
    if resp.status_code != 200:
        click.echo(resp.text)
        raise click.Abort()
    if output is None:
        click.echo(resp.json())
    else:
        click.echo(output_convertion(resp.json(), output))