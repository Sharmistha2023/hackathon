import click
import requests
import json
from tabulate import tabulate
import webbrowser 
import os
import yaml
from d3x_cli.utils import  get_formatted_name,output_convertion
class Struct:
    def __init__(self, **entries):
        self.__dict__.update(entries)

DOCKER_SERVER = os.environ.get("DOCKER_SERVER","https://index.docker.io/v1/")
DOCKER_USER = os.environ.get("DOCKER_USER","")
DOCKER_PASSWORD = os.environ.get("DOCKER_PASSWORD","")

@click.group()
@click.pass_context
def apps(ctx):
    """Group for apps commands."""
    pass

def get_apps(obj, ns=None):
    params = {}
    if ns != None:
        params={"namespace": ns}
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/apps/", params=params, headers=obj.headers, verify=False)
    if r.status_code == 200:
        return r.json()
    else:
        print(r.text)
    return []

def get_user_apps(obj, name, user= None, publish=False):
    if user == None:
        user = obj.username
    data = get_apps(obj, user)
    app = None
    for d in data:
        if not publish:
            if d["owner"] == user and d["name"] == name and d["publish"] == False:
                app = d
                break
        else:
            if d["name"] == name and d["publish"] == True:
                app = d
                break
    if app == None:
        print(f" {name} for the user {user} not found")
        raise click.Abort()
    return Struct(**app)

@apps.command()
@click.pass_obj
@click.option("-a", "--all", required=False, is_flag=True, type=bool, help="list userapps including shared users")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def list(obj,output, all=False):
    """List user apps"""
    ns = "*" if all else None
    apps = get_apps(obj, ns)
    userapps = [[ "user", "app name", "published", "status", "image", "memory(GB)", "cores", "gpu",  "url"]]
    for userapp in apps:
        app = Struct(**userapp)
        ingressprefix= f"{obj.url}{app.url}"
        app.memory = app.memory if app.memory != -1 else "unlimited"
        app.cpu_count = app.cpu_count if app.cpu_count != -1 else "unlimited"
        userapps.append([ app.owner, app.name, app.publish, app.status, app.image, app.memory, app.cpu_count, app.gpu_count, ingressprefix])
    if output is None:
        print(tabulate(userapps, headers="firstrow", tablefmt="presto"))
    else:
        output_convertion(userapps, output)


@apps.command(context_settings=dict(ignore_unknown_options=True))
@click.argument("command", nargs=-1, type=click.UNPROCESSED)
@click.option("-c", "--config",required=True, help="Path to the YAML configuration file")
@click.pass_obj
def create(obj,config,command):
    """deploy the user app on dkubex"""
    fd = os.open(config, os.O_RDONLY)
    with os.fdopen(fd, 'r') as f:
        yaml_data = yaml.safe_load(f)

    image = yaml_data.get("image")
    name = yaml_data.get("name")
    cpu = yaml_data.get("cpu", -1)
    gpu = yaml_data.get("gpu", 0)
    memory = yaml_data.get("memory", -1)
    dockerserver = yaml_data.get("dockerserver", "DOCKER_SERVER")
    dockeruser = yaml_data.get("dockeruser", "DOCKER_USER")
    dockerpsw = yaml_data.get("dockerpsw", "DOCKER_PASSWORD")
    publish = yaml_data.get("publish", "false")
    env = yaml_data.get("env", [])
    port = yaml_data.get("port", "8080")
    description = yaml_data.get("description", "")
    rewritetarget = yaml_data.get("rewritetarget", "false")
    configsnippet = yaml_data.get("configsnippet", "")
    ingressprefix = yaml_data.get("ingressprefix")
    output = yaml_data.get("output")
    mount_home = yaml_data.get("mount_home")
    
    route_type = yaml_data.get("route_type", "ingress")
    hostname = yaml_data.get("hostname", "")
    certs =  yaml_data.get("certs", "")
    if certs != "":
        if "tls.crt" in certs and "tls.key" in certs:
            import base64
            with open(certs.get("tls.crt"), "rb") as cert_file:
                cert_data = cert_file.read()
                base64_encoded_data = base64.b64encode(cert_data)
                base64_encoded_string = base64_encoded_data.decode('utf-8')
                certs["tls.crt"] = base64_encoded_string
            with open(certs.get("tls.key"), "rb") as cert_file:
                cert_data = cert_file.read()
                base64_encoded_data = base64.b64encode(cert_data)
                base64_encoded_string = base64_encoded_data.decode('utf-8')
                certs["tls.key"] = base64_encoded_string
        certs = json.dumps(certs)
    
    if rewritetarget == None :
        rewritetarget = False if publish == "true" else True
    else:
        rewritetarget = True if rewritetarget == "true" else False

    portobj = {"port":int(port), "rewrite-target": rewritetarget, "configuration-snippet": configsnippet}
    if hostname == "":
        if ingressprefix != None:
            if not ingressprefix.startswith("/"):
                ingressprefix = f"/{ingressprefix}"
            portobj["ingress-prefix"] = ingressprefix
        elif publish == "true" :
            ingressprefix = f"/{name}"
    elif ingressprefix == None:
        ingressprefix = "/"

    ingress = {name : [portobj]}
    cmd = ' '.join(command)
    ingressstr = json.dumps(ingress)
    reqobj = {"userapp": { "name": name, "description" :description, "image" : image,  "cpu_count": cpu, 
               "gpu_count": gpu, "memory": memory, "command": cmd, "publish":True if publish == "true" else False,
                 "env": json.dumps(env), "docker_registry_username" : dockeruser, "docker_registry_password": dockerpsw,
                  "ingress": ingressstr, "docker_registry_server": dockerserver,
                  "mount_home": mount_home, "route_type": route_type, "hostname" : hostname, "certs": certs}}
    if "metrics" in yaml_data:
        reqobj["userapp"]["metrics"] = json.dumps(yaml_data.get("metrics"))
    if ingressprefix != None:
        reqobj["userapp"]["url"] = ingressprefix 
    if output is None:
        print(json.dumps(reqobj, indent=4))
    else:
        output_convertion(reqobj, output)
    json_data = json.dumps(reqobj)
    r = requests.post(f"{obj.url}/api/{obj.api_prefix}/apps/",  data=json_data, headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    # click.echo(output_convertion(r.json(), output))
    click.echo(r.json()["status"])

@apps.command()
@click.pass_obj
@click.argument("name")
@click.option("-u", "--user", required=False, default=None, help="app's owner name")
@click.option("-p", "--published", required=False, is_flag=True, type=bool, help="published userapp")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)

def delete(obj, name,output, user=None, published=False):
    """Delete user apps"""
    if user != None and published:
        click.echo("--user is not supported with --published")
        raise click.Abort()
    
    app = get_user_apps(obj, name, user, published)
    
    r = requests.delete(f"{obj.url}/api/{obj.api_prefix}/apps/{app.id}", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    if output is None:
        click.echo(r.json()["status"])
    else:
        click.echo(output_convertion(r.json()["status"], output))


@apps.command()
@click.pass_obj
@click.argument("name")
@click.option("-u", "--user", required=False, default=None, help="app's owner name")
@click.option("-p", "--published", required=False, is_flag=True, type=bool, help="published userapp")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)

def start(obj, name, output, user=None, published = False):
    """start user apps"""
    if user != None and published:
        click.echo("--user is not supported with --published")
        raise click.Abort()
    app = get_user_apps(obj, name, user, publish=published)
    r = requests.post(f"{obj.url}/api/{obj.api_prefix}/apps/{app.id}/start", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    if output is None:
        click.echo(r.json()["status"])
    else:
        click.echo(output_convertion(r.json()["status"], output))

@apps.command()
@click.pass_obj
@click.argument("name")
@click.option("-u", "--user", required=False, default=None, help="app's owner name")
@click.option("-p", "--published", required=False, is_flag=True, type=bool, help="published userapp")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)

def stop(obj, name, output, user=None, published=False):
    """stop user apps"""
    if user != None and published:
        click.echo("--user is not supported with --published")
        raise click.Abort()
    app = get_user_apps(obj, name, user, publish=published)
    r = requests.post(f"{obj.url}/api/{obj.api_prefix}/apps/{app.id}/stop", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    if output is None:
        click.echo(r.json()["status"])
    else:
        click.echo(output_convertion(r.json()["status"], output))
    # click.echo(r.json()["status"])

@apps.command("open")
@click.pass_obj
@click.option("-u", "--user", required=False, default=None, help="app's owner name")
@click.option("-p", "--published", required=False, is_flag=True, type=bool, help="published userapp")
@click.argument("name")
def open_app(obj, name, user=None, published=False):
    """Open user app in browser"""
    app = get_user_apps(obj, name, user,published)
    if app.hostname != "":
        from urllib.parse import urlparse
        parsed_url = urlparse(obj.url)
        url = obj.url.replace(parsed_url.netloc.split(":")[0],  app.hostname) + "/"
    else:
        url = f"{obj.url}/{app.uuid}/{app.name}/"
    webbrowser.open(url, new=0, autoraise=True)

