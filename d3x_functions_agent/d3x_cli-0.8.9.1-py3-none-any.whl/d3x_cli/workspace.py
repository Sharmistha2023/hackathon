import requests
from tabulate import tabulate
import click
from d3x_cli.utils import  get_formatted_name, output_convertion, catch_os_exec
import os
import platform
import subprocess
from d3x_cli.tensorboard import tensorboard
from d3x_cli.optuna import optuna
host_type = platform.system()
from d3x_cli.workspace_helper import *

@click.group()
@click.pass_context        
def ws(ctx):
    """Group for workspace commands."""
    pass
ws.add_command(tensorboard)
ws.add_command(optuna)
@ws.command()
@click.pass_obj
@click.option("-a", "--all", required=False, is_flag=True, type=bool, help="list workspaces including shared users")
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)
def list(obj,output, all):
    """List d3x workspaces"""
    all = "*" if all == True else None    
    list_workspaces(obj,output, all)


@ws.command()
@click.pass_obj
@click.option("-u", "--user", required=False, default=None, help="name of the workspace user")
def start(obj, user):
    """Start given workspace"""
    start_stop_workspace(obj, "start",  ns=user)

@ws.command()
@click.option("-u", "--user", required=False, default=None, help="name of the workspace user")
@click.pass_obj
def stop(obj, user):
    """Stop given workspace"""
    start_stop_workspace(obj, "stop",  ns=user)

@ws.command()
@click.pass_obj
@click.option("-u", "--user", required=False, default=None, help="name of the workspace user")
def reset(obj, user):
    """reset given workspace to default image"""
    start_stop_workspace(obj, "reset", ns=user)


@ws.command()
@click.pass_obj
@click.option("-u", "--user", required=False, default=None, help="name of the workspace user")
@click.argument("app_name")
def start_app(obj, app_name, user):
    """Start given workspace app"""
    start_stop_workspace_app(obj, app_name, "start", user)

@ws.command()
@click.pass_obj
@click.argument("app_name")
@click.option("-u", "--user", required=False, default=None, help="name of the workspace user")
def stop_app(obj, app_name, user):
    """Stop given workspace App"""
    start_stop_workspace_app(obj, app_name, "stop", user)

@ws.command(context_settings=dict(ignore_unknown_options=True))
@click.option("-u", "--user", required=False, default=None, help="name of the workspace user")
@click.argument("command", nargs=-1, type=click.UNPROCESSED)
@click.pass_obj
def ssh(obj, user, command):
    """SSH to D3X workspace"""
    w = get_user_workspace(obj, user)
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/workspaces/{w.id}/services", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    if user == None:
        user = obj.username
    resp = r.json()
    host = resp["ip"]
    port = resp["ports"]["ssh"]
    print(f"running ssh {user}@{host} -p {port} {' '.join(command)}")
    a = ["ssh", "-o StrictHostKeyChecking=no", f"{user}@{host}", "-p", str(port)]
    a.extend(command)
    if host_type == "Windows":
        subprocess.run(a)
    else:
        os.execvp("ssh", a)

@ws.command(context_settings=dict(ignore_unknown_options=True))
@click.argument("public_key")
@click.option("-u", "--user", required=False, default=None, help="name of the workspace user")
@click.pass_obj
def ssh_copy_id(obj, public_key, user):
    """Copy ssh public key to D3X user's home"""
    key = ""
    w = get_user_workspace(obj, user)
    with open(public_key, 'r') as file:
        key = file.read().rstrip()
    if key == "":
        click.echo("inproper key")
        raise click.Abort()
    data = {"key": key}
    r = requests.post(f"{obj.url}/api/{obj.api_prefix}/sshkeys/{w.owner}", headers=obj.headers,  json=data, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    print("successfully copied the public key")


@ws.command()
@click.pass_obj
@click.option("-u", "--user", required=False, default=None, help="name of the workspace user")
@catch_os_exec
def code(obj, user):
    """Start local VSCode and connect to D3X workspace"""
    w = get_user_workspace(obj, user)
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/workspaces/{w.id}/services", headers=obj.headers, verify=False, allow_redirects=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()
    if user == None:
        user = obj.username
    resp = r.json()
    host = resp["ip"]
    port = resp["ports"]["ssh"]
    print(f"running code {user}@{host} -p {port}")
    if host_type == "Darwin":
        code = "/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code"
    else:
        code = subprocess.run("which code", stdout=subprocess.PIPE, shell=True).stdout.decode().strip()
    folder =  f"vscode-remote://ssh-remote+{user}@{host}:{port}/home/{user}"
    os.execlp(code,"code", "--folder-uri", folder)

@ws.command()
@click.pass_obj
@click.option("-u", "--user", required=False, default=None, help="name of the workspace user")
@catch_os_exec
def vnc(obj, user):
    """VNC connection to  D3X workspace"""
    w = get_user_workspace(obj, user)
    if user == None:
        user = obj.username
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/workspaces/{w.id}/services", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()

    resp = r.json()
    host = resp["ip"]
    port = resp["ports"]["vnc"]
    uuid = resp["uuid"]
    print(f"connecting to VNC server at {host}:{port}. password: {uuid}")
    
    if host_type == "Linux": 
        os.execlp("vncviewer","vncviewer", f"{host}:{port}")
    elif host_type == "Darwin":
        os.execlp("open", "open", f"vnc://{user}@{host}:{port}")

@ws.command()
@click.pass_obj
@click.argument("source")
@click.argument("target")
def scp(obj, source, target):
    """COPY files(s)/directory from/to D3X workspace"""

    if ":" not in source and ":" not in target:
        raise click.UsageError("source or target needs to be of the format <worksapce_name>:/path")

    local_source = False

    if ":" in source:
        user = source.split(":")[0]
        source = source.split(":")[1]
    else:
        user = target.split(":")[0]
        local_source = True
        target = target.split(":")[1]
    w = get_user_workspace(obj, user)
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/workspaces/{w.id}/services", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()

    resp = r.json()
    host = resp["ip"]
    port = resp["ports"]["ssh"]
    user = user
    if local_source:
        if target == "" or target[0] not in ["~","/"]:
            target = f"workspaces/{user}/{target}"
        print("scp", "-r", "-P", str(port), source, f"{user}@{host}:{target}")
        os.execlp("scp","scp", "-o StrictHostKeyChecking=no", "-r", "-P", str(port), source, f"{user}@{host}:{target}")
    else:
        if source == "" or source[0] not in ["~","/"]:
            source = f"workspaces/{user}/{source}"
        print("scp", "-r", "-P", str(port), f"{user}@{host}:{source}", target)
        os.execlp("scp","scp", "-o StrictHostKeyChecking=no", "-r", "-P", str(port), f"{user}@{host}:{source}", target)

@ws.command()
@click.pass_obj
@click.argument("service")
@click.argument("target_port")
@click.argument("local_port")
@click.option("-u", "--user", required=False, default=None, help="name of the workspace user")
def port_forward(obj, service, target_port, local_port):
    """Forward port from workspace to local computer"""
    w = get_user_workspace(obj, user)
    if user == None:
        user = obj.username
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/workspaces/{w.id}/services", headers=obj.headers, verify=False)
    if r.status_code != 200:
        click.echo(r.text)
        raise click.Abort()

    resp = r.json()
    host = resp["ip"]
    port = resp["ports"]["ssh"]
    a = ["ssh", "-L", f"{local_port}:{service}:{target_port}","-o StrictHostKeyChecking=no", f"{user}@{host}", "-p", str(port)]
    if host_type == "Windows":
        subprocess.run(a)
    else:
        os.execvp("ssh", a)