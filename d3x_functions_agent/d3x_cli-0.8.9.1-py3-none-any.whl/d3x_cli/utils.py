import os
import re
import yaml
import json
import requests


def catch_os_exec(func):
    def wrapper(*args, **kwargs):
        try:
            func(*args, **kwargs)
        except FileNotFoundError:
            print(f"Please install {func.__name__} and try again.")

    wrapper.__name__ = func.__name__
    wrapper.__doc__ = func.__doc__
    return wrapper


def get_request_headers(cookie=None, token=None):
    if cookie != None:
        headers = {"Cookie": f"_oauth2_proxy={cookie}"}
    else:
        headers = {"Authorization": token}
    return headers


class ContextObj(object):
    def __init__(self, config, profile):
        self.profile = profile
        self.username = config.get(
            profile, "username", fallback=os.environ.get("USER", "")
        )
        self.url = config.get(profile, "url")
        self.hpc_url = config.get("default", "hpc_url", fallback=self.url)
        if config.has_option(profile, "auth-type"):
            auth_type = config.get(profile, "auth-type")
            if auth_type == "cookie":
                cookie = config.get(profile, "cookie")
                self.headers = get_request_headers(cookie=cookie)
            else:
                token = config.get(profile, "auth-token")
                self.headers = get_request_headers(token=token)

            self.api_prefix = config.get(profile, "api-prefix")
            self.auth_type = auth_type
        self.config = config
        self.obj = None


def get_formatted_name(name):
    name = re.sub("[^A-Za-z0-9-]+", "-", name).lower()
    return name.strip("-")


def output_convertion(input_data, formats, details=None, message=None):
    """Convert input data to specified format and print the result."""
    try:
        # Convert input data to consistent dictionary format
        if isinstance(input_data, list) and input_data:
            header = input_data[0]
            data = [dict(zip(header, row)) for row in input_data[1:]]
        elif isinstance(input_data, str):
            data = input_data.split('\n')
        else:
            data = input_data
            
        # Create result dictionary
        result = {
            "status": "Success",
            "details": data
        }
        
        # Format according to specified output type
        if formats == "yaml":
            output = yaml.dump(result, default_flow_style=False)
        elif formats == "json":
            output = json.dumps(result, indent=2)
        else:
            output = str(result)
            
        print(output)
    except Exception as e:
        print(yaml.dump({"status": "Failure", "details": str(e)}, default_flow_style=False))


def get_dkubex_apikey(obj):
    r = requests.get(f"{obj.url}/api/{obj.api_prefix}/apikey/", headers=obj.headers, verify=False)
    if r.status_code != 200:
        assert False, f"Failed to get dkubex apikey. Return status code: {r.status_code}"
    return r.json()
