import click
import requests
import json
import os
import time
from pathlib import Path
import yaml
# from d3serve.logger import logger
from d3x_cli.utils import  get_formatted_name,output_convertion, get_dkubex_apikey
userdata_dir = (
    "/userdata" if "D3X_NAMESPACE" in os.environ else str(Path.home())
)
ini_file = f"{userdata_dir}/.d3x.ini"

from websockets.sync.client import connect
from websockets.exceptions import ConnectionClosedError

class Struct:
    def __init__(self, **entries):
        self.__dict__.update(entries)


def url_prefix(context):
    if context.auth_type == "cookie":
        prefix = "llms"
    else:
        # TODO: can we change the name to 'serve' instead of 'llm'
        prefix = "llm"
    return prefix


CLI_CTX_OBJ = None


@click.group()
@click.pass_obj
def emb(obj):
    """Group for embedding commands."""
    global CLI_CTX_OBJ
    CLI_CTX_OBJ = obj


@emb.command()
@click.pass_obj
@click.option("-n", "--name", required=True, help="name of the deployment")
@click.option(
    "-m",
    "--model",
    required=False,
    help="name or path of the model to deploy for embeddings",
)
@click.option("--base_model", required=False, help="base model name")
@click.option("--token", help="hugging face token")
@click.option("--config", help="github raw content url or local config path")
@click.option(
    "--mlflow",
    help="name of the mlflow registered model along with version (example: diffusion:1)",
)
@click.option(
    "--image", required=False, help='''docker image for dkubex emb deployment use following\n
                        CPU	ghcr.io/huggingface/text-embeddings-inference:cpu-1.6 \n
                        Turing (T4, RTX 2000 series, ...)	ghcr.io/huggingface/text-embeddings-inference:turing-1.6\n
                        Ampere 80 (A100, A30)	ghcr.io/huggingface/text-embeddings-inference:1.6 \n
                        Ampere 86 (A10, A40, ...)	ghcr.io/huggingface/text-embeddings-inference:86-1.6 \n
                        Ada Lovelace (RTX 4000 series, ...)	ghcr.io/huggingface/text-embeddings-inference:89-1.6 \n
                        Hopper (H100)	ghcr.io/huggingface/text-embeddings-inference:hopper-1.6
    '''
)
@click.option("--type", "instance_type", help="instance type")
@click.option("--min_replicas", help="minimum replicas")
@click.option("--max_replicas", help="maximum replicas")
@click.option("--publish", is_flag=True, help="publish the deployment")
@click.option(
    "-p",
    "--provider",
    required=False,
    default="dkubex",
    help="provider of llm [default is dkubex]",
)
@click.option(
    "--ngc-api-key", "ngcapikey", required=False, help="NGC API key for nim provider"
)
@click.option(
    "--qps", "qps", required=False, help="questions per second for autoscaling"
)

@click.option(
    "-o",
    "--output",
    required=False,
    type=click.Choice(
        [
            "yaml",
            "json",
        ]
    ),
    help="supported only json,yaml",
)
@click.option(
    "-sky",
    "--sky",
    "skyjob",
    required=False,
    default=False,
    is_flag=True,
    help="If the model should be deployed on remote sky cluster.",
)
@click.option(
    "--sky-accelerator",
    "accelerator",
    required=False,
    help="accelerator for remote sky cluster",
)
@click.option(
    "--sky-yaml",
    "sky_yaml",
    required=False,
    default=None,
    help="Path to custom yaml file for sky serve.",
)
@click.option(
    "-sc",
    "--sky-cloud",
    "sky_cloud",
    required=False,
    help="Name of the sky cloud, if not provided cloud will be selected based on cost.",
)

@click.option(
    "--ngpus",
    "ngpus",
    default=0,
    help="no of gpus",
)

@click.option(
    "--ncpus",
    "ncpus",
    required=False,
    help="no.of cpus",
)

@click.option(
    "--memory",
    "memory",
    required=False,
    help="memory in GB",
)
def deploy(
    obj,
    name,
    model,
    base_model,
    token,
    config,
    mlflow,
    image,
    instance_type,
    min_replicas,
    max_replicas,
    publish,
    provider,
    ngcapikey,
    qps,
    output,
    skyjob,
    sky_cloud,
    accelerator,
    sky_yaml,
    ngpus,
    ncpus,
    memory,
):
    """Deploy a llm on dkubex."""
    if skyjob and not ( model or config or mlflow):
        print("Please provide a model (--model) for deploying on remote sky cluster")
        return

    dkubex_apikey = None
    if (skyjob): #assert dkubex_apikey, "For sky jobs, -k/--dkubex-apikey must be passed."
        dkubex_apikey = get_dkubex_apikey(obj)
    else :
        if provider == "dkubex" and ngpus > 0 and not image:
            print('''please provide --image for deploying dkubex models in gpu\n
            GPU TYPE                            IMAGE \n\n
            Turing (T4, RTX 2000 series, ...)	ghcr.io/huggingface/text-embeddings-inference:turing-1.6\n
            Ampere 80 (A100, A30)               ghcr.io/huggingface/text-embeddings-inference:1.6 \n
            Ampere 86 (A10, A40, ...)	        ghcr.io/huggingface/text-embeddings-inference:86-1.6 \n
            Ada Lovelace (RTX 4000 series, ...)	ghcr.io/huggingface/text-embeddings-inference:89-1.6 \n
            Hopper (H100)                       ghcr.io/huggingface/text-embeddings-inference:hopper-1.6
            ''')
            return
    if provider == "nim":
        if  ngcapikey==None:
            print("Please provide --ngc-api-key")
            click.Abort()
            return
        else:
            token = ngcapikey
    if not model and not config and not mlflow:
        print("please provide either model, config ")
        return
    
    if mlflow:
        token = ""

    if config:
        with open(config, "r") as file:
            yamlstr = file.read()
            config = yaml.safe_load(yamlstr)


    data = {
        "depname": name,
        "embmdl": {
            "name": model,
            "token": token,
            "config": config,
            "image": image,
            "base_model": base_model,
            "instance_type": instance_type,
            "publish": publish,
            "mlflow": mlflow,
            "provider": provider,
            "kserve": True,
            "ngpus": ngpus,
        },
        "sky": {
            "skyjob": skyjob,
            "accelerator": accelerator,
            "sky_yaml": sky_yaml,
            "no_stream": True
        },
        "dkubex_apikey": dkubex_apikey,
    }
    if sky_cloud:
        data["sky"]["sky_cloud"] = sky_cloud
    prefix = url_prefix(obj)
    if min_replicas:
        data["embmdl"]["min_replicas"] = min_replicas
    if max_replicas:
        data["embmdl"]["max_replicas"] = max_replicas
    
    if ncpus:
        data["embmdl"]["ncpus"] = ncpus
    if memory:
        data["embmdl"]["memory"] = str(memory)
    if qps:
        data["embmdl"]["qps"] = qps
    post_url = f"{obj.url}/{prefix}/api/embs/deploy"
    if (skyjob) :
        post_url =  f"{obj.url}/{prefix}/api/embs/deploy/sky"

    r = requests.post(
        post_url,
        json=data,
        headers=obj.headers,
        verify=False,
        timeout=360,
    )

    if r.status_code != 200:
        print(f"Failed to deploy model. Status code: {r.status_code}, {r.text}")
        return

    if skyjob:
        data =""
        while True:
            r = requests.get (
                f"{obj.url}/{prefix}/api/skydeploymentstatus/{name}",
                headers=obj.headers,
                verify=False,
                timeout=360,
                )
            
            if r.status_code != 200:
                print(f"Failed to deploy model. Status code: {r.status_code} , {r.text}")
                return
            
            resp = r.json()
            if resp["status"] in ["init", "deploying"]:
                msg = resp["logs"]
                msg = msg.replace(data, "")
                print(msg, end="", flush=True)
                data =  resp["logs"]
            else:
                status = resp["status"]
                print(f"deployment {name} is in {status} state")
                break
            time.sleep(10)

        return

    if output is None:
        print(r.json())
    else:
        output_convertion(r.json(), output)

    return


# TODO Use/Modify the below code block, when enabling use of emb model with mlflow.
# @emb.command()
# @click.pass_obj
# @click.option("-n", "--name", required=True, help="name of the model for registration")
# @click.option(
#    "-f", "--file", required=True, help="raw github url of model definition in yaml"
# )
# @click.option("-o","--output", required=False,
#     type=click.Choice(
#         [
#             "yaml",
#             "json",
#         ]
#     ),
#     help="supported only json,yaml",
# )

# def register(obj, name, file,output):
#     """Register a model with dkubex"""
#     # MAK - TODO
#     pattern = r"https://raw\.githubusercontent\.com/[^/]+/[^/]+/[^/]+/[^/]+/.+"
#     if not re.match(pattern, file):
#         print("please provide valid raw github url")
#         return
#     prefix = url_prefix(obj)
#     data = {"name": name, "file": file}
#     resp = requests.post(
#         f"{obj.url}/{prefix}/api/llms/register",
#         json=data,
#         headers=obj.headers,
#         verify=False,
#     )
#     if output is None:
#         print(resp.json())
#     else:
#         output_convertion(resp.json(), output)

#     return

@emb.command()
@click.pass_obj
@click.option("-o","--output", required=False,
    type=click.Choice(
        [
            "yaml",
            "json", 
        ]
    ),
    help="supported only json,yaml",
)

def list(obj, output=None):
    """List all supported embedding models."""
    prefix = url_prefix(obj)
    resp = requests.get(
        f"{obj.url}/{prefix}/api/embs/", headers=obj.headers, verify=False
    )
    
    if resp.status_code != 200:
        print(f"Failed to retrieve embedding models. Status code: {resp.status_code}, {resp.text}")
        return
    
    embs_data = resp.json().get("embs", [])
    embs_data = sorted(embs_data, key=lambda x: x.get("name", ""))
    
    if output:
        # Prepare data for structured output
        table_output = [["Emb Model Name", "Model ID", "Accelerator",  "Provider", "Deployment Config"]]
        for entry in embs_data:
            table_output.append([
                entry["name"],
                entry["model_id"], 
                entry["accelerator"], 
                entry["provider"], 
                entry.get("config", "")
            ])
        output_convertion(table_output, output)
    else:
        # Display as rich table
        from rich.console import Console
        from rich.table import Table
        
        console = Console()
        table = Table(
            show_header=True,
            header_style="bold magenta",
            title="Embedding models supported on DKubeX",
            show_lines=True
        )
        
        table.add_column("Name")
        table.add_column("Model ID")
        table.add_column("Accelerator")
        table.add_column("Provider")
        table.add_column("Deployment Config", justify="left")
        
        for entry in embs_data:
            table.add_row(
                entry.get("name", ""),
                entry.get("model_id", ""),
                entry.get("accelerator", ""),
                entry.get("provider", "dkubex"),
                entry.get("config", "")
            )

        console.print(table)
